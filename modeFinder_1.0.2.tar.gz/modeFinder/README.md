# modeFinder

## Mode estimation via Bernstein polynomials

The R function is based on the draft of:

Bowen Liu and Sujit K. Ghosh, *”On empirical estimation of mode based on weakly dependent samples”*, in preparation.
