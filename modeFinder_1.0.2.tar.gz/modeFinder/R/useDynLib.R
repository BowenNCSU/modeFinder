#' @useDynLib modeFinder
NULL